<?php

require_once '../tool/conjunto.php';
require_once '../tool/multiple_files/Envoltura.php';

/*
require_once './tool/conjunto.php';
require_once './tool/multiple_files/Envoltura.php';
*/