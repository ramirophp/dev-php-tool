<?php

require_once '../tool/multiple_files/Piezas.php';
require_once '../tool/multiple_files/Etiqueta.php';
require_once '../tool/multiple_files/Atributo.php';
require_once '../tool/multiple_files/Atributos.php';
require_once '../tool/multiple_files/Elemento.php';

/*
require_once './tool/multiple_files/Piezas.php';
require_once './tool/multiple_files/Etiqueta.php';
require_once './tool/multiple_files/Atributo.php';
require_once './tool/multiple_files/Atributos.php';
require_once './tool/multiple_files/Elemento.php';
*/