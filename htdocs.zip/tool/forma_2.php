<?php

require_once '../tool/conjunto.php';
require_once '../tool/multiple_files/XYZ.php';

/*
require_once './tool/conjunto.php';
require_once './tool/multiple_files/XYZ.php';
*/